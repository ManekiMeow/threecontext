import json,pathlib,subprocess,time
root=pathlib.Path('/workspace/threecontext')
out=root/'search/overnight30_phase_reviews/2026-11-05T0200'
order=[0,1,2,3,4,6,9,10,11,12,5]
start=time.monotonic(); records=[]
for index in order:
 remaining=120-(time.monotonic()-start)
 if remaining<6: break
 before=time.monotonic()
 command=['/workspace/threecontext-venv/bin/python','search/event30_c5_general_phases.py','search','--source',str(out/'targets.json'),'--index',str(index),'--seconds',str(remaining-3),'--output-dir',str(out/f'target_{index:03}')]
 result=subprocess.run(command,cwd=root,capture_output=True,text=True)
 row={'index':index,'requested_seconds':remaining-3,'wall_seconds':time.monotonic()-before,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
 records.append(row)
 (out/'batch_log.json').write_text(json.dumps({'budget_seconds':120,'order':order,'elapsed_seconds':time.monotonic()-start,'records':records},indent=2)+'\n')
 print(json.dumps({k:v for k,v in row.items() if k not in ['stderr','stdout']})+' '+result.stdout.strip(),flush=True)
 if result.returncode: break
print('BATCH_SECONDS',time.monotonic()-start,flush=True)
