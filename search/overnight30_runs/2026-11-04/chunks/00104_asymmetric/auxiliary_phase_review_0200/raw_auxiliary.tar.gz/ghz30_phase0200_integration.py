import copy,gzip,hashlib,itertools,json,pathlib,subprocess,sys,time
root=pathlib.Path('/workspace/threecontext');sys.path.insert(0,str(root/'search'))
import overnight30_quotient as q
import overnight30_symmetry as s
import overnight30_screen as screen
from event30_c5_phases import graph6
from overnight30_fast_dual import verify_certificate as verify_dual
from pysat.formula import IDPool
from pysat.solvers import Cadical153
import networkx as nx
out=root/'search/overnight30_phase_reviews/2026-11-05T0200'
start=time.monotonic(); patterns=q.pattern_catalog();catalog_seconds=time.monotonic()-start
permutation=s.generator('c5_double');edge_variables={};orbits=[]
for u in range(30):
 for v in range(u+1,30):
  if u//10==v//10 or (u,v) in edge_variables:continue
  orbit=[];current=(u,v)
  while current not in orbit:
   orbit.append(current);current=tuple(sorted((permutation[current[0]],permutation[current[1]])))
  orbits.append(sorted(orbit))
  for edge in orbit:edge_variables[edge]=len(orbits)
cnfstart=time.monotonic();clauses,metadata=q.quotient_exclusion_cnf(edge_variables,IDPool(start_from=len(orbits)+1));cnf_seconds=time.monotonic()-cnfstart
solver=Cadical153(bootstrap_with=clauses)
summary=json.loads((out/'summary.json').read_text());checks=tampers=0
for row in summary['results']:
 manifest=json.loads((root/row['manifest']).read_text());base=q.graph_data({'graph6':manifest['records'][0]['graph6']})
 for order in q.orbit_orders():
  mapping=[5*order[v//5]+v%5 for v in range(30)]
  edges=sorted(tuple(sorted((mapping[u],mapping[v]))) for u,v in base['edges'])
  cert=q.find_obstruction({'edges':edges});assert cert and cert['method']=='c5_phase_quotient'
  q.verify_certificate(cert)
  actual=set(edges);assumptions=[i if all(e in actual for e in orbit) else -i for i,orbit in enumerate(orbits,1)]
  assert not solver.solve(assumptions=assumptions)
  cut={'clause':s.dominance_clause(cert['graph'],orbits),'reason':'verified_structural_dominance','witness':{'graph6':graph6(edges),'method':cert['method'],'witness':cert['witness']}}
  assert s.replay_structural_dominance(json.loads(json.dumps(cut)),orbits)==cut['clause']
  checks+=1
 bad=copy.deepcopy(cert);bad['witness']['phase_certificate']['manifest_sha256']='0'*64
 try:q.verify_certificate(bad)
 except ValueError:tampers+=1
 else:raise AssertionError('altered manifest hash accepted')
solver.delete()
seeds_path=root/'search/overnight30_symmetry_seeds.json';seeds=json.loads(seeds_path.read_text());retired=0
for seed in seeds['c5_double']:
 if seed.get('exact_obstruction'):continue
 cert=q.find_obstruction(seed)
 if cert:
  q.verify_certificate(cert);seed['exact_obstruction']={'method':cert['method'],'witness':cert['witness']}
  seed['scope']='Exactly excluded by complete C5 phase enumeration; retained only as a historical mutation guide.'
  seed['screen_status']='Excluded by all-phase exact theta certificates for this quotient, recorded in the 02:00 phase review.'
  seed['provenance']['review']='Previously selected from stored residual-review representatives; now every cyclic phase is exactly excluded. The full published-pool representative ranking can differ from that review list.'
  retired+=1
candidates=json.loads((out/'guide_candidates.json').read_text())['results'];guide=None
for candidate in candidates:
 if q.find_obstruction(candidate) is not None:continue
 scr=screen.fast_screen(candidate)
 if scr['status']=='excluded':continue
 graph=nx.Graph();graph.add_nodes_from(range(30));graph.add_edges_from(q.graph_data(candidate)['edges'])
 if s.bad_coloring(graph) is not None:continue
 guide=dict(candidate);guide['screen']=scr;break
assert guide is not None
commit='3536304a360437b6c54413602377c31438c719f0'
raw=subprocess.check_output(['git','show',commit+':'+guide['source']],cwd='/workspace/ghz30-overnight');matched=[]
for line_number,line in enumerate(gzip.decompress(raw).splitlines()):
 record=json.loads(line)
 if record.get('index')==guide['index']:
  assert record['graph6']==guide['graph6'] and record['theta_numeric']==guide['theta_numeric'];matched.append(line_number)
assert len(matched)==1
entry={'graph6':guide['graph6'],'context_sizes':[10,10,10],'theta_numeric':guide['theta_numeric'],'edges_count':len(q.graph_data(guide)['edges']),'provenance':{'source':guide['source'],'record_index':guide['index'],'line_number_zero_based':matched[0],'published_commit':commit,'source_sha256':hashlib.sha256(raw).hexdigest(),'review':'Highest-scoring published quotient representative after updating the full pinned pool and applying all verified catalogs plus support/coloring screens.'},'scope':'Numerical mutation guide; the individual support is exactly excluded, while its whole cyclic phase family is unresolved.','screen_status':'Survives current exact combinatorial support screens and verified quotient-class catalogs.'}
if 'dominance_certificate_sha256' in guide:
 digest=guide['dominance_certificate_sha256'];path=str(pathlib.Path(guide['source']).parent/'dual_cuts'/(digest+'.json.gz'))
 packed=subprocess.check_output(['git','show',commit+':'+path],cwd='/workspace/ghz30-overnight');decoded=gzip.decompress(packed);assert hashlib.sha256(decoded).hexdigest()==digest
 proof=json.loads(decoded);assert proof['edges']==q.graph_data(guide)['edges'];upper=verify_dual(proof);assert str(upper)==guide['exact_theta_upper']
 (out/'best_guide_individual_dual.json.gz').write_bytes(packed)
 entry.update(individual_exact_theta_upper=str(upper),individual_exact_certificate=path,individual_exact_certificate_sha256=digest)
else:
 entry['scope']='Numerical mutation guide only; no quantum feasibility or exact theta claim.'
if not any(row['graph6']==entry['graph6'] for row in seeds['c5_double']):seeds['c5_double'].append(entry)
seeds_path.write_text(json.dumps(seeds,indent=2)+'\n')
report={'patterns':len(patterns),'clauses':len(clauses),'auxiliary_variables':metadata['auxiliary_variables'],'new_phase_relabel_sat_replay_checks':checks,'tamper_checks':tampers,'catalog_seconds':catalog_seconds,'cnf_seconds':cnf_seconds,'total_seconds':time.monotonic()-start,'retired_seeds':retired,'next_guide_theta':guide['theta_numeric'],'next_guide_source':guide['source'],'next_guide_index':guide['index'],'next_guide_line_number_zero_based':matched[0],'next_guide_exact_upper':entry.get('individual_exact_theta_upper')}
(out/'integration_checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
