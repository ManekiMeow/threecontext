import argparse,json,sys,time
from pathlib import Path
sys.path.insert(0,'/workspace/threecontext/search')
from event30_c5_general_phases import search

def main():
    root=Path('/workspace/threecontext')
    folder=root/'search/overnight30_phase_reviews/2026-11-05T0100'
    started=time.monotonic();seconds=90
    for index in [0,1,2,4,3]:
        remaining=seconds-(time.monotonic()-started)
        if remaining<2:break
        args=argparse.Namespace(source=folder/'targets.json',index=index,seconds=remaining,output_dir=folder/f'target_{index:03}')
        print(json.dumps({'starting_target':index,'remaining_seconds':remaining}),flush=True)
        search(args)
    print(json.dumps({'batch_elapsed_seconds':time.monotonic()-started}),flush=True)
if __name__=='__main__':main()
