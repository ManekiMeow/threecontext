import copy,gzip,json,sys,time
from pathlib import Path
sys.path.insert(0,'/workspace/threecontext/search')
from pysat.formula import IDPool
from pysat.solvers import Cadical153
import overnight30_quotient as q
from overnight30_symmetry import dominance_clause,replay_structural_dominance
start=time.monotonic()
patterns=q.pattern_catalog();loaded=time.monotonic()
variables={}
orbits=[]
for index,(a,b) in enumerate(q.PAIRS):
 for shift in range(5):
  orbit=[(5*a+i,5*b+(i+shift)%5) for i in range(5)]
  orbits.append(orbit)
  for edge in orbit:variables[edge]=5*index+shift+1
clauses,info=q.quotient_exclusion_cnf(variables,IDPool(start_from=61));built=time.monotonic()
folder=Path('/workspace/threecontext/search/overnight30_phase_reviews/2026-11-05T0100')
summary=json.loads((folder/'summary.json').read_text())
checks=tampers=0
with Cadical153(bootstrap_with=clauses) as solver:
 for entry in summary['results']:
  manifest=json.loads((Path('/workspace/threecontext')/entry['manifest']).read_text())
  base=q.graph_data({'graph6':manifest['records'][0]['graph6']})
  for order in q.orbit_orders():
   mapping={5*a+i:5*order[a]+i for a in range(6) for i in range(5)}
   graph=q.graph_data({'edges':[[mapping[u],mapping[v]] for u,v in base['edges']]})
   proof=q.find_obstruction(graph)
   assert proof is not None
   q.verify_certificate(proof)
   selected={variables[tuple(edge)] for edge in graph['edges']}
   assumptions=[v if v in selected else -v for v in range(1,61)]
   assert not solver.solve(assumptions=assumptions)
   from event30_c5_phases import graph6
   cut={'clause':dominance_clause(graph,orbits),'reason':'verified_structural_dominance','witness':{'graph6':graph6(map(tuple,graph['edges'])),'method':proof['method'],'witness':proof['witness']}}
   assert replay_structural_dominance(cut,orbits)==cut['clause']
   checks+=1
  proof=q.find_obstruction(base)
  if proof['method']=='c5_phase_quotient':
   bad=copy.deepcopy(proof);bad['witness']['phase_certificate']['manifest_sha256']='0'*64
   try:q.verify_certificate(bad)
   except ValueError:tampers+=1
   else:raise AssertionError('changed manifest accepted')
 residual=json.loads(Path('/tmp/ghz30-residual-0100.json').read_text())
 guide=None
 from overnight30_screen import fast_screen
 for row in residual:
  graph=q.graph_data(row)
  if q.find_obstruction(graph) is None and fast_screen(graph)['status']=='not_excluded':
   selected={variables[tuple(edge)] for edge in graph['edges']}
   assert solver.solve(assumptions=[v if v in selected else -v for v in range(1,61)])
   guide=row;break
 assert guide is not None
 Path('/tmp/ghz30-phase0100-next-guide.json').write_text(json.dumps(guide,indent=2)+'\n')
report={'patterns':len(patterns),'clauses':len(clauses),'auxiliary_variables':info['auxiliary_variables'],'new_phase_relabel_sat_replay_checks':checks,'tamper_checks':tampers,'catalog_seconds':loaded-start,'cnf_seconds':built-loaded,'total_seconds':time.monotonic()-start,'next_guide_theta':guide['theta_numeric'],'next_guide_source':guide['source'],'next_guide_index':guide['index']}
(folder/'integration_checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
q.self_test()
