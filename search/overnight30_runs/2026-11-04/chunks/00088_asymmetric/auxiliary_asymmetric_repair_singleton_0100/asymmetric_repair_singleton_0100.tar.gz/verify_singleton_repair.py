"""Exact singleton-block compatibility regression; no numerical solves."""
import copy
import json
from pathlib import Path
import random
import sys

HERE = Path(__file__).resolve().parent
sys.path.insert(0, '/workspace/threecontext/search')
from overnight30_asymmetric import PARTS, decode, partition_witness_repair, validate
from overnight30_screen import verify_certificate

parent = json.loads((HERE / 'singleton_parent.json').read_text())
original = copy.deepcopy(parent)
verify_certificate(parent['certificate'])
witness = parent['certificate']['witness']
assert sorted(len(block['vertices']) for block in witness['blocks']) == [1, 4, 5]
assert witness['budget'] == '1411/1440'
singleton = next(block for block in witness['blocks'] if len(block['vertices']) == 1)
assert singleton['other_context'] is None
for seed in range(32):
    proposed = partition_witness_repair(parent, random.Random(seed))
    assert proposed is not None
    trial, provenance = proposed
    assert validate(trial)
    assert len(provenance['certificate_block']['vertices']) >= 2
    assert provenance['certificate_block']['other_context'] is not None
    u, v = provenance['sharing_pair']
    b = provenance['shared_neighbor']
    assert trial[u] >> b & 1 and trial[v] >> b & 1
    assert not (decode(parent['g6'])[u] >> b & 1)
    assert proposed == partition_witness_repair(parent, random.Random(seed))
    assert parent == original
report = {'singleton_partition_sizes': [5, 4, 1], 'singleton_other_context': None,
          'exact_partition_budget': '1411/1440', 'certificate_verified': True,
          'repair_proposals': 32, 'deterministic_replays': 32,
          'all_selected_blocks_nonsingleton': True, 'input_record_unmodified': True,
          'source_graph_id': parent['graph_id'],
          'scope': 'Nonnumerical regression on an actual certified 01:00 review representative.'}
(HERE / 'singleton_verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
