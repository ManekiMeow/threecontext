# Additive singleton-block correction

This archive supplements, and does not replace, the 01:00 asymmetric repair
archive with SHA256 c473903d6ce20cc592b83d9d5a4095769e48f344b1af3eee6f6937651e52c0b4.
Independent code review found that valid disjoint-partition certificates may have
singleton blocks whose `other_context` is null. The worker now skips these blocks
after verifying the complete certificate, since they have no disjoint pair to
repair. This prevents indexing a context list with null.

The regression uses actual frozen review representative 4c1f39a97ef002e02c6f:
`search/overnight30_reviews/2026-11-05T0100/4c1f39a97ef002e02c6f_certificate.json`.
Its 5+4+1 partition has exact budget 1411/1440. All 32 seeded repair proposals and
32 deterministic replays passed support validation, selected nonsingleton
blocks, preserved a pair of edges sharing the target neighbor, and left the
original record unchanged. No numerical search or SDP solve was performed.
The original raw archive and original published review remain untouched.
