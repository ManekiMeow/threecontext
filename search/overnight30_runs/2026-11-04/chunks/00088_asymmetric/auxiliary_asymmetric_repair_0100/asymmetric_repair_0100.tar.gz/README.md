# 01:00 asymmetric witness-repair auxiliary batch

This is a bounded construction experiment, not a nonexistence proof. The pinned
published pool is commit `5a2b45478d066d5180d1364259e1c7b1d233fc33`. Its strongest
historical asymmetric-worker guide has numerical theta 2.9166384145 and an exact
disjoint-partition probability budget 15/16. Its full automorphism group has order
two; its context-preserving group is trivial.

The archived `repair.py` enumerated 80 shared-neighbor edge targets, 276 minimal
triangle-conflict choices and two deterministic maximal completions each. Of 552
completion attempts, 249 repeated a within-batch label and 80 repeated a scored
published label. All 223 remaining labels were processed within 19.634 seconds:
118 had exact pre-score exclusions and 105 were numerically scored without solver
failures. H33 and H36 served as positive controls. `pre_score_certificates.jsonl.gz`
contains independently replayed certificates for all 118 pre-score exclusions
(114 disjoint partitions and four iterated probability budgets).

The 105 scored labels contain 55 exact uncolored isomorphism representatives
within this batch, with 50 explicit mappings. This is not an isomorphism census
against the entire previous pool. The strongest new guide, theta 2.9092320745,
has trivial full automorphism group and independently verified rational theta
upper bound 29103/10000. It is excluded individually and retained only to guide
mutations. No global event-number or dimension bound changes.

`verify_repair.py` independently checks certificate/graph binding, all exact
certificates, all batch maps and pairwise nonisomorphism, the best automorphism
order, 32 seeded combinatorial worker proposals and their deterministic replays,
and rejection of a mismatched parent certificate. It performs no SDP solves.
`worker_with_repair.py` freezes the worker implementation after the controlled
move was integrated; it is not a claim that the batch used that new move.
The integration samples a certified historical partition every 128 ordinary
proposals and preserves existing screens, mutation weights and acceptance rules.

Raw construction results, inputs, source hashes, best proof, isomorphism maps and
verification output are preserved here. Source paths in the small scripts assume
the documented `/workspace/threecontext` checkout and experiment worktree; all
inputs required for exact replay are also local to this archive.
