"""Bounded exact-witness-breaking constructions; numerical results are not realizations."""
import argparse,collections,gzip,hashlib,itertools,json,random,subprocess,sys,time
from pathlib import Path
ROOT=Path('/workspace/threecontext')
DATA=Path('/workspace/ghz30-overnight')
sys.path.insert(0,str(ROOT/'search'))
from overnight30_asymmetric import (PARTS,PART_MASKS,decode,encode,edges_of,remove,add,fill,validate,screened,ThetaScorer,positive_controls)
from overnight30_screen import verify_certificate
CUTOFF='5a2b45478d066d5180d1364259e1c7b1d233fc33'
BASE='search/overnight30_runs/2026-11-04/chunks/00079_asymmetric/asymmetric_seed20261104_best_excluded.json'
OUT=Path(__file__).resolve().parent

def blob(path):
    return subprocess.check_output(['git','show',CUTOFF+':'+path],cwd=DATA)

def published_labels():
    manifest=json.loads(blob('search/overnight30_runs/2026-11-04/manifest.json'))
    seen=set();sources=[]
    for job in manifest['jobs']:
        if job.get('state')!='completed':continue
        folder=DATA/job['directory']
        files=list(folder.glob('*.jsonl.gz'))+list(folder.glob('**/models.jsonl.gz'))
        for path in files:
            raw=path.read_bytes(); count=0
            for line in gzip.decompress(raw).splitlines():
                r=json.loads(line)
                if ('theta' in r or 'theta_numeric' in r) and 'g6' in r:
                    seen.add(r['g6']);count+=1
                elif 'theta_numeric' in r and 'graph6' in r:
                    seen.add(r['graph6']);count+=1
            sources.append({'path':str(path.relative_to(DATA)),'sha256':hashlib.sha256(raw).hexdigest(),'scored_records':count})
    return seen,sources

def main(seconds):
    base_raw=blob(BASE); base=json.loads(base_raw); cert=base['certificate']
    verify_certificate(cert); assert cert['method']=='disjoint_partition'
    original=decode(base['g6']); original_edges=set(edges_of(original))
    seen,sources=published_labels()
    counts=collections.Counter(); candidates={}
    for block in cert['witness']['blocks']:
        vertices=block['vertices'];other=block['other_context']
        if len(vertices)<2:continue
        for v in vertices:
            for b in range(10*other,10*other+10):
                if not original[v]>>b&1:continue
                for u in vertices:
                    if u==v or original[u]>>b&1:continue
                    counts['target_added_edges']+=1
                    blockers=[c for c in range(30) if (original[u]&original[b])>>c&1]
                    for choices in itertools.product((0,1),repeat=len(blockers)):
                        counts['minimal_conflict_choices']+=1
                        trial=original[:];removed=[]
                        for c,choice in zip(blockers,choices):
                            edge=(u,c) if choice==0 else (b,c)
                            remove(trial,*edge);removed.append(sorted(edge))
                        add(trial,u,b)
                        for completion in range(2):
                            counts['completion_attempts']+=1
                            seed=1000003*u+10007*b+101*sum((i+1)*x for i,x in enumerate(choices))+completion
                            made=fill(trial[:],random.Random(seed))
                            assert made[u]>>b&1 and made[v]>>b&1
                            if not validate(made):counts['invalid_completion']+=1;continue
                            code=encode(made)
                            if code in seen:counts['already_scored_labels']+=1;continue
                            if code in candidates:counts['duplicate_candidates']+=1;continue
                            edges=set(edges_of(made))
                            candidates[code]={'g6':code,'added_target':sorted((u,b)),'sharing_pair':sorted((u,v)),
                                              'shared_neighbor':b,'removed_conflicts':removed,
                                              'edge_difference':len(edges^original_edges),'completion_seed':seed}
    counts['new_candidates']=len(candidates)
    start=time.monotonic();deadline=start+seconds;scorer=ThetaScorer(30)
    controls=positive_controls()
    records=[];best=None; screened_counts=collections.Counter()
    ordered=sorted(candidates.values(),key=lambda r:(r['edge_difference'],r['g6']))
    for cand in ordered:
        if time.monotonic()>=deadline-.2:break
        adj=decode(cand['g6']); screen=screened(adj)
        method=(screen.get('certificate') or {}).get('method','not_excluded')
        screened_counts[method]+=1
        if screen['status']=='excluded':
            records.append({**cand,'screen_method':method,'status':'exactly_excluded_before_score'})
            continue
        result=scorer.solve(adj,limit=min(2,max(.05,deadline-time.monotonic())))
        if 'error' in result:
            records.append({**cand,'status':'numerical_failure','error':result['error']})
            continue
        screen=screened(adj,result['theta'])
        record={**cand,'status':'scored','theta_numeric':result['theta'],'screen_status':screen['status'],
                'screen_method':(screen.get('certificate') or {}).get('method'),'solver':result['solver'],
                'diagnostics':result['diagnostics'],'parts':PARTS,'edges':edges_of(adj)}
        records.append(record)
        if best is None or result['theta']>best['theta_numeric']:best=record
    counts.update({'processed_candidates':len(records),'scored':sum(r['status']=='scored' for r in records),
                   'numerical_failures':sum(r['status']=='numerical_failure' for r in records)})
    summary={'scope':'Bounded witness-guided construction, not an exhaustive local or global exclusion.',
             'published_cutoff':CUTOFF,'parent_path':BASE,'parent_sha256':hashlib.sha256(base_raw).hexdigest(),
             'parent_g6':base['g6'],'parent_theta_numeric':base['theta_numeric'],
             'parent_obstruction':cert['method'],'parent_obstruction_budget':cert['witness']['budget'],
             'counts':dict(counts),'screen_method_counts':dict(screened_counts),'best':best,
             'search_seconds':time.monotonic()-start,'requested_seconds':seconds,'positive_controls':controls,
             'deduplication':'Only exact graph6 labels against scored records in completed main-worker archives; not an isomorphism census.'}
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    (OUT/'sources.json').write_text(json.dumps(sources,indent=2)+'\n')
    (OUT/'candidates.jsonl').write_text(''.join(json.dumps(r,separators=(',',':'))+'\n' for r in records))
    (OUT/'parent.json').write_bytes(base_raw)
    print(json.dumps({k:v for k,v in summary.items() if k!='best'},indent=2))
    print('best',None if best is None else best['theta_numeric'])

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seconds',type=float,default=20);a=p.parse_args();main(a.seconds)
