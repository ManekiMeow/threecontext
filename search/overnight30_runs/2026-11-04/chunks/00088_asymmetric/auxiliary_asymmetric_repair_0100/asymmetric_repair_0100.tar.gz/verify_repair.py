"""Replay exact witnesses, batch maps and nonnumerical worker repair controls."""
import copy
import gzip
import json
from pathlib import Path
import random
import sys

import networkx as nx

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspace/threecontext/search')
sys.path.insert(0, str(ROOT))
from overnight30_asymmetric import (PARTS, decode, encode, edges_of, from_edges,
                                   partition_witness_repair, validate)
from overnight30_screen import verify_certificate

parent = json.loads((HERE / 'parent.json').read_text())
original = copy.deepcopy(parent)
summary = json.loads((HERE / 'summary.json').read_text())
best = summary['best']
dual = json.loads((HERE / 'best_exact_dual.json').read_text())
verify_certificate(parent['certificate'])
verify_certificate(dual)
assert from_edges(dual['graph']['edges']) == decode(best['g6'])
assert dual['graph']['parts'] == best['parts'] == PARTS
assert partition_witness_repair(None, random.Random(17)) is None
assert partition_witness_repair({'certificate': {'method': 'theta_dual'}}, random.Random(17)) is None
bad = copy.deepcopy(parent)
bad['g6'] = best['g6']
try:
    partition_witness_repair(bad, random.Random(17))
except ValueError:
    pass
else:
    raise AssertionError('mismatched certificate graph accepted')
outputs = []
for seed in range(32):
    result = partition_witness_repair(parent, random.Random(seed))
    assert result is not None
    trial, provenance = result
    replay = partition_witness_repair(parent, random.Random(seed))
    assert result == replay
    assert validate(trial)
    u, v = provenance['sharing_pair']
    b = provenance['shared_neighbor']
    assert trial[u] >> b & 1 and trial[v] >> b & 1
    adj = decode(parent['g6'])
    assert not (adj[u] & adj[v]) & sum(1 << w for w in PARTS[b // 10])
    conflicts = [c for c in range(30) if (adj[u] & adj[b]) >> c & 1]
    assert len(provenance['removed_conflicts']) == len(conflicts)
    assert all([u, c] in provenance['removed_conflicts'] or [b, c] in provenance['removed_conflicts'] for c in conflicts)
    assert parent == original
    outputs.append(encode(trial))

batch = json.loads((HERE / 'batch_isomorphism.json').read_text())
records = [json.loads(line) for line in (HERE / 'candidates.jsonl').read_text().splitlines()]
scored = {row['g6'] for row in records if row['status'] == 'scored'}
representatives = [json.loads(line)['g6'] for line in (HERE / 'representatives.jsonl').read_text().splitlines()]
assert len(scored) == 105 and len(representatives) == 55
assert len(set(representatives)) == len(representatives)
for item in batch['maps']:
    a, b = decode(item['graph6']), decode(item['representative_graph6'])
    permutation = item['permutation']
    assert sorted(permutation) == list(range(30))
    mapped = {tuple(sorted((permutation[u], permutation[v]))) for u, v in edges_of(a)}
    assert mapped == set(edges_of(b))
    assert item['representative_graph6'] in representatives
assert set(representatives) | {r['graph6'] for r in batch['maps']} == scored
# WL buckets are only a speed-up; every same-bucket pair gets exact VF2.
buckets = {}
for code in representatives:
    graph = nx.from_graph6_bytes(code.encode())
    bucket = nx.weisfeiler_lehman_graph_hash(graph)
    for prior in buckets.get(bucket, []):
        assert not nx.is_isomorphic(graph, prior)
    buckets.setdefault(bucket, []).append(graph)
graph = nx.from_graph6_bytes(best['g6'].encode())
assert sum(1 for _ in nx.algorithms.isomorphism.GraphMatcher(graph, graph).isomorphisms_iter()) == 1
pre_score = [json.loads(line) for line in gzip.open(HERE / 'pre_score_certificates.jsonl.gz', 'rt')]
assert len(pre_score) == 118
for row in pre_score:
    verify_certificate(row['certificate'])
    assert from_edges(row['certificate']['graph']['edges']) == decode(row['g6'])
assert {row['g6'] for row in pre_score} == {row['g6'] for row in records if row['status'] == 'exactly_excluded_before_score'}
report = {'pre_score_certificates': len(pre_score), 'worker_repair_controls': 32, 'deterministic_replays': 32,
          'distinct_control_labels': len(set(outputs)), 'input_record_unmodified': True,
          'mismatched_certificate_rejected': True, 'verified_batch_maps': len(batch['maps']),
          'pairwise_nonisomorphic_batch_representatives': len(representatives),
          'best_full_automorphism_order': 1, 'exact_best_upper': dual['witness']['bound'],
          'scope': 'Exact replay and combinatorial controls; no new numerical solves.'}
(HERE / 'verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
