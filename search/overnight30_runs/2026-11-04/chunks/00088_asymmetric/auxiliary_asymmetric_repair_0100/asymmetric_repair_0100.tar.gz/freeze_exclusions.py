"""Freeze exact certificates for every pre-score rejection in the saved batch."""
import collections, gzip, json, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,'/workspace/threecontext/search')
from overnight30_asymmetric import PARTS, decode, edges_of
from overnight30_screen import fast_screen, verify_certificate
out=[]
for line in (HERE/'candidates.jsonl').read_text().splitlines():
    row=json.loads(line)
    if row['status']!='exactly_excluded_before_score':continue
    cert=fast_screen({'parts':PARTS,'edges':edges_of(decode(row['g6']))})['certificate']
    verify_certificate(cert)
    assert cert['method']==row['screen_method'], (cert['method'],row['screen_method'])
    out.append({'g6':row['g6'],'certificate':cert})
with gzip.open(HERE/'pre_score_certificates.jsonl.gz','wt') as stream:
    for row in out:stream.write(json.dumps(row,separators=(',',':'))+'\n')
print(dict(collections.Counter(row['certificate']['method'] for row in out)))
