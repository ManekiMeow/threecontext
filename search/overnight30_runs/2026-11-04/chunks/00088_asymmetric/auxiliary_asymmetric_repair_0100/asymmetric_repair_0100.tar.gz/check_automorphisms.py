"""Exact automorphism counts for two pinned asymmetric-worker records."""
import json,sys
from pathlib import Path
import networkx as nx
HERE=Path(__file__).resolve().parent
EXPECTED=json.loads((HERE/'automorphisms.json').read_text())
result={}
for name in ('best','best_excluded'):
 r=EXPECTED[name]
 g=nx.from_graph6_bytes(r['g6'].encode())
 nx.set_node_attributes(g,{i:i//10 for i in range(30)},'part')
 mappings=list(nx.algorithms.isomorphism.GraphMatcher(g,g).isomorphisms_iter())
 colored=sum(1 for _ in nx.algorithms.isomorphism.GraphMatcher(g,g,node_match=lambda a,b:a['part']==b['part']).isomorphisms_iter())
 result[name]={'theta':r['theta'],'g6':r['g6'],'automorphisms_uncolored':len(mappings),
               'automorphisms_context_preserving':colored,
               'nonidentity_mappings':[[m[i] for i in range(30)] for m in mappings if any(m[i]!=i for i in range(30))]}
assert result==EXPECTED
print(json.dumps(result,indent=2))
