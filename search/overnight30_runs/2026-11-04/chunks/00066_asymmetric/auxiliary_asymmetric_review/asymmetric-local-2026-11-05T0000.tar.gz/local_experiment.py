import time
start=time.monotonic()
import sys,json,gzip,itertools,random
from pathlib import Path
import numpy as np
sys.path.insert(0,'/workspace/threecontext/search')
from overnight30_asymmetric import (PARTS,PAIRS,from_edges,decode,encode,edges_of,addable,add,remove,fill,validate,screened,ThetaScorer,positive_controls)
root=Path('/workspace/threecontext')
review=root/'search/overnight30_reviews/2026-11-05T0000'
ids=['5e8f40b8d72c15cfd969','2f290839c0a70e778c8a','90ed924eba2d67ae2e74','e3e13c31ef6174b72b19']
rows=[json.loads(line) for line in (review/'strongest_candidates.jsonl').read_text().splitlines()]
parents=[next(row for row in rows if row['graph_id']==gid) for gid in ids]
edges=[set(edges_of(decode(row['g6']))) for row in parents]
common=set.intersection(*edges)
union=set.union(*edges)
choices=sorted(union-common)
known=set()
for p in Path('/workspace/ghz30-overnight/search/overnight30_runs/2026-11-04/chunks').glob('*_asymmetric/*.jsonl.gz'):
 with gzip.open(p,'rt') as stream:
  for line in stream:
   row=json.loads(line)
   if 'theta' in row: known.add(row['g6'])
controls=positive_controls()
adj=from_edges(common)
scorer=ThetaScorer(30)
output=Path('/tmp/ghz30-asymmetric-0000-local')
output.mkdir(exist_ok=True)
counts={'dfs_nodes':0,'maximal_union_supports':0,'already_scored':0,'screen_excluded':0,'scored':0,'solver_errors':0}
seen=set()
answers=[]
budget=14.5
finished=True

def visit(i):
 global finished
 counts['dfs_nodes']+=1
 if time.monotonic()-start>budget-0.4:
  finished=False
  return
 if i<len(choices):
  u,v=choices[i]
  if addable(adj,u,v):
   add(adj,u,v)
   visit(i+1)
   remove(adj,u,v)
  visit(i+1)
  return
 if any(addable(adj,u,v) for u,v in choices): return
 if not validate(adj): return
 counts['maximal_union_supports']+=1
 trial=fill(adj[:],random.Random(71007+counts['maximal_union_supports']))
 if not validate(trial): return
 code=encode(trial)
 if code in seen: return
 seen.add(code)
 if code in known:
  counts['already_scored']+=1
  return
 screen=screened(trial)
 if screen['status']=='excluded':
  counts['screen_excluded']+=1
  return
 answer=scorer.solve(trial,limit=min(2,budget-(time.monotonic()-start)))
 if 'error' in answer:
  counts['solver_errors']+=1
  return
 counts['scored']+=1
 screen=screened(trial,answer['theta'])
 spectrum=np.linalg.eigvalsh(answer['B'])
 row={'g6':code,'theta_numeric':answer['theta'],'parts':PARTS,'edges':edges_of(trial),
      'screen':{key:screen[key] for key in ('status','reason','dimension19_eligible','coloring_search') if key in screen},
      'numerical_theta_primal_ranks':{str(t):int(sum(spectrum>t)) for t in (1e-5,1e-6,1e-7)},
      'scope':'bounded direct recombination; numerical theta-primal ranks are not physical realization dimensions'}
 answers.append(row)
 print(json.dumps({'theta':row['theta_numeric'],'screen':row['screen']}),flush=True)
visit(0)
summary={'parents':ids,'common_edges':len(common),'union_edges':len(union),'varying_edges':len(choices),
         'known_labelled_scored_supports':len(known),'counts':counts,'enumeration_finished':finished,
         'elapsed_seconds':time.monotonic()-start,'controls':controls,
         'best_new_theta':max((r['theta_numeric'] for r in answers),default=None),
         'scope':'finite union recombination with one greedy completion per maximal support; no global nonexistence conclusion'}
(output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(output/'candidates.jsonl').write_text(''.join(json.dumps(row,separators=(',',':'))+'\n' for row in answers))
print(json.dumps(summary),flush=True)
